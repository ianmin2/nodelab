(function(){

	var app = angular.module("toDO", []);

	app.controller("NavbarController", function(){
		
		this.el = navData;
		
	}); 
	
	var navData = {
			
			/* The menu/application header */
			title : "my to~Do",
			
			/* The Submenu elements */
			submenus : [
				{ title : "Home", link: "#home" },
				{ title : "About", link: "#about" }
			],
			
			dropdowns: [
			            /* Dropdown item */
			            { 
			            	/* label to display on the trigger item */
			            	title: "Others", 
			            	
			            	/* The href of the item */
			            	link: "#", 
			            	
			            	/* The menu elements */
			            	menu_items: [
			            	        
			            	        {
			            	        	/* Menu category header */
					            		header: "Admin && Dash",
					            		
					            		/* Menu category items */
					            		items : [
					            			{ title : "Opt 1", link : "#opt1" },
					            			{ title : "Opt 2", link : "#opt2" }
					            		]
			            	        
			            	        } ,
			            	        
			            	        {
			            	        	/* Other menu category header */
					            		header: "Admin2 && Dash2",
					            		
					            		/* Other menu category items */
					            		items : [
					            			{ title : "Opt 1", link : "#opt1_2" },
					            			{ title : "Opt 2", link : "#opt2_2" }
					            		]
			            	        }
					            	
			            	        
			            	]
			            	
			            }
			            ]
	}
	
	 
	
})();
